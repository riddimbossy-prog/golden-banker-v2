/* Predict2U v171 — Growth & Sharing */
(function(){
  "use strict";
  const VERSION="v202", REF_KEY="p2u_referral_code", METRIC_KEY="p2u_share_metrics_v171";
  const icon='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.7 6.8-4.1M8.6 13.3l6.8 4.1"/></svg>';
  const esc=s=>String(s||'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]));
  function referral(){const u=new URL(location.href);const r=(u.searchParams.get('ref')||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,32);if(r)localStorage.setItem(REF_KEY,r);return r||localStorage.getItem(REF_KEY)||''}
  function withRef(raw){const u=new URL(raw,location.href);const r=referral();if(r)u.searchParams.set('ref',r);return u.toString()}
  function metric(channel,type){try{const m=JSON.parse(localStorage.getItem(METRIC_KEY)||'{}');const k=`${type||'page'}:${channel}`;m[k]=(m[k]||0)+1;m.lastAt=new Date().toISOString();localStorage.setItem(METRIC_KEY,JSON.stringify(m));window.dispatchEvent(new CustomEvent('p2u:share',{detail:{channel,type,version:VERSION}}))}catch(_){}}
  function toast(msg){let el=document.querySelector('.p2u-share-toast');if(!el){el=document.createElement('div');el.className='p2u-share-toast';el.setAttribute('role','status');document.body.appendChild(el)}el.textContent=msg;el.classList.add('is-show');clearTimeout(el._t);el._t=setTimeout(()=>el.classList.remove('is-show'),1800)}
  function pageData(source){
    const card=source&&source.closest&&source.closest('[data-p2u-match-key],.slip-card,[data-slip-id],article');
    if(card&&card.dataset.p2uMatchKey){const home=card.dataset.p2uHome||'',away=card.dataset.p2uAway||'',market=card.dataset.p2uMarket||'',league=card.dataset.p2uLeague||'';return{type:'match',title:`${home} vs ${away}`,text:[league,market].filter(Boolean).join(' · '),url:withRef(`${location.origin}${location.pathname}?match=${encodeURIComponent(card.dataset.p2uMatchKey)}`)}}
    if(card&&(card.classList.contains('slip-card')||card.dataset.slipId)){const heading=card.querySelector('h2,h3,strong,.slip-title');return{type:'community',title:(heading&&heading.textContent.trim())||'Predict2U Community record',text:'View this public community record on Predict2U.',url:withRef(location.href.split('#')[0]+(card.id?`#${card.id}`:''))}}
    const title=document.querySelector('h1')?.textContent.trim()||document.title.replace(/\s*[|—-].*$/,'');return{type:'page',title,text:document.querySelector('meta[name="description"]')?.content||'Explore transparent football records and engine analysis on Predict2U.',url:withRef(location.href)}
  }
  async function copy(text){try{await navigator.clipboard.writeText(text);return true}catch(_){const t=document.createElement('textarea');t.value=text;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();const ok=document.execCommand('copy');t.remove();return ok}}
  function ensureSheet(){let ov=document.querySelector('.p2u-share-overlay');if(ov)return ov;ov=document.createElement('div');ov.className='p2u-share-overlay';ov.innerHTML='<section class="p2u-share-sheet" role="dialog" aria-modal="true" aria-labelledby="p2u-share-title"><div class="p2u-share-head"><div><h2 class="p2u-share-title" id="p2u-share-title">Share Predict2U</h2><p class="p2u-share-summary"></p></div><button class="p2u-share-close" aria-label="Close share panel">×</button></div><div class="p2u-share-grid"></div><div class="p2u-share-url"></div><p class="p2u-share-note">Records and analysis only. Predict2U handles no money. 18+.</p></section>';document.body.appendChild(ov);ov.addEventListener('click',e=>{if(e.target===ov||e.target.closest('.p2u-share-close'))closeSheet()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeSheet()});return ov}
  function closeSheet(){document.querySelector('.p2u-share-overlay')?.classList.remove('is-open')}
  function shareUrl(channel,d){const enc=encodeURIComponent;const body=enc(`${d.title}\n${d.text}\n${d.url}`);if(channel==='whatsapp')return`https://wa.me/?text=${body}`;if(channel==='facebook')return`https://www.facebook.com/sharer/sharer.php?u=${enc(d.url)}`;if(channel==='telegram')return`https://t.me/share/url?url=${enc(d.url)}&text=${enc(d.title+' — '+d.text)}`;if(channel==='x')return`https://twitter.com/intent/tweet?text=${enc(d.title+' — '+d.text)}&url=${enc(d.url)}`;return d.url}
  async function openSheet(source){const d=pageData(source);if(navigator.share&&matchMedia('(max-width:760px)').matches){try{await navigator.share({title:d.title,text:d.text,url:d.url});metric('native',d.type);return}catch(e){if(e&&e.name==='AbortError')return}}
    const ov=ensureSheet(),grid=ov.querySelector('.p2u-share-grid');ov.querySelector('.p2u-share-title').textContent=d.title;ov.querySelector('.p2u-share-summary').textContent=d.text;ov.querySelector('.p2u-share-url').textContent=d.url;grid.innerHTML=['whatsapp','facebook','telegram','x'].map(c=>`<a class="p2u-share-action" data-channel="${c}" href="${shareUrl(c,d)}" target="_blank" rel="noopener">${c==='x'?'X':c[0].toUpperCase()+c.slice(1)}</a>`).join('')+'<button class="p2u-share-action" data-copy="link">Copy link</button><button class="p2u-share-action" data-copy="summary">Copy summary</button>';
    grid.querySelectorAll('[data-channel]').forEach(a=>a.addEventListener('click',()=>metric(a.dataset.channel,d.type)));grid.querySelector('[data-copy="link"]').addEventListener('click',async()=>{await copy(d.url);metric('copy-link',d.type);toast('Link copied')});grid.querySelector('[data-copy="summary"]').addEventListener('click',async()=>{await copy(`${d.title}\n${d.text}\n${d.url}`);metric('copy-summary',d.type);toast('Summary copied')});ov.classList.add('is-open');ov.querySelector('.p2u-share-close').focus()}
  function button(){const b=document.createElement('button');b.type='button';b.className='p2u-share-card-btn';b.innerHTML=icon+'<span>Share</span>';b.setAttribute('aria-label','Share this record');b.addEventListener('click',()=>openSheet(b));return b}
  function decorate(root=document){let count=0;root.querySelectorAll('[data-p2u-match-key],.slip-card,[data-slip-id]').forEach(card=>{if(card.dataset.p2uShareReady)return;card.dataset.p2uShareReady='1';const host=card.querySelector('.p2u-card-actions,.slip-actions,.actions')||card;host.appendChild(button());count++});if(count)window.dispatchEvent(new CustomEvent('p2u:growth-decorated',{detail:{count}}));return count}
  function schema(){if(document.querySelector('script[data-p2u-growth-schema]'))return;const s=document.createElement('script');s.type='application/ld+json';s.dataset.p2uGrowthSchema='1';s.textContent=JSON.stringify({'@context':'https://schema.org','@type':'WebSite',name:'Predict2U',url:location.origin+'/',description:document.querySelector('meta[name="description"]')?.content||'Transparent football records and engine analysis.',potentialAction:{'@type':'SearchAction',target:location.origin+location.pathname+'?q={search_term_string}','query-input':'required name=search_term_string'}});document.head.appendChild(s);let canonical=document.querySelector('link[rel="canonical"]');if(!canonical){canonical=document.createElement('link');canonical.rel='canonical';document.head.appendChild(canonical)}canonical.href=location.origin+location.pathname;let og=document.querySelector('meta[property="og:url"]');if(!og){og=document.createElement('meta');og.setAttribute('property','og:url');document.head.appendChild(og)}og.content=location.href}
  const decorateRoots=new Set();
  let decorateQueued=false;
  function scheduleDecorate(root=document){
    decorateRoots.add(root||document);
    if(decorateQueued)return;
    decorateQueued=true;
    requestAnimationFrame(()=>{
      decorateQueued=false;
      const work=[...decorateRoots];decorateRoots.clear();
      work.forEach(node=>decorate(node&&node.querySelectorAll?node:document));
    });
  }
  function install(){
    // v202 owns the install prompt centrally. Keeping a second beforeinstallprompt
    // listener caused prompt races and instruction screens on supported browsers.
    window.addEventListener('appinstalled',()=>toast('Predict2U installed'));
  }
  function init(){
    referral();schema();decorate();
    new MutationObserver(mutations=>{
      for(const mutation of mutations){
        for(const node of mutation.addedNodes){
          if(node.nodeType===1)scheduleDecorate(node.matches?.('[data-p2u-match-key],.slip-card,[data-slip-id]')?node.parentElement:node);
        }
      }
    }).observe(document.body,{childList:true,subtree:true});
    document.addEventListener('click',e=>{const t=e.target.closest('[data-p2u-share-page]');if(t)openSheet(t)});
    install();
    window.P2UGrowthSharing={version:VERSION,share:openSheet,withReferral:withRef,decorate,metrics:()=>JSON.parse(localStorage.getItem(METRIC_KEY)||'{}')};
    document.documentElement.dataset.p2uGrowthReady='true';
    window.dispatchEvent(new CustomEvent('p2u:growth-ready',{detail:{version:VERSION}}));
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
